✅ Tau Stars бот (Render-ready)
1. Render.com → New → Web Service → Manual deploy → Upload zip
2. Start command: python TauStarsRef.py
3. Python version автоматты түрде 3.10.13 болады (.python-version арқылы)
