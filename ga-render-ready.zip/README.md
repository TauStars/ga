# TauStars GA Bot (Render-Ready)

This repository is configured for deployment to Render with Python 3.10.

## Files Added
- `.python-version`: Specifies Python 3.10.13 for Render.
- `render.yaml`: Render service configuration forcing Python runtime.
- `requirements.txt`: Python dependencies (`aiogram==3.0.0b7`).
- `TauStarsRef.py`: Telegram bot code.

## Deployment on Render
1. Fork or push this repo to your GitHub account.
2. On Render.com, create a new **Web Service**:
   - Connect your GitHub repo.
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `python TauStarsRef.py`
3. Deploy and enjoy your bot!
